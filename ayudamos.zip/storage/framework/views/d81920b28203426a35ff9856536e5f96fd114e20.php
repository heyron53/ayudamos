
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
      <h1>BANEOS</h1>
    <ul class="nav nav-tabs">
    <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="listarUsuarios">Listar usuarios</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="listarDenuncias">Listar denuncias</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="listarBaneos">Listar baneos</a>
            </li>
    </ul>

    <div class="row alert">
    <div class="table-responsive">
            <table class="table table-bordered bg-white text-dark table stacktable" id="myTable">
                  <thead>
                        <tr>
                              <th scope="col">CodBan</th>
                              <th scope="col">CodUsuBan</th>
                              <th scope="col">TipoBaneo</th>
                              <th scope="col">Mensaje</th>
                              <th scope="col">FechaInicio</th>
                              <th scope="col">FechaFin</th>
                              <th scope="col"></th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $baneos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baneo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                              <td><?php echo e($baneo->codBan); ?></td>
                              <td><?php echo e($baneo->codUsuBan); ?></td>
                              <td><?php echo e($baneo->tipoBaneo); ?></td>
                              <td><?php echo e($baneo->mensaje); ?></td>
                              <td><?php echo e($baneo->fechaInicio); ?></td>
                              <td><?php echo e($baneo->fechaFin); ?></td>
                              <td>
                              <form action="eliminarBaneo" method="POST">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('POST'); ?>
                                    <input type="hidden" name="codBan" value="<?php echo e($baneo->codBan); ?>">
                                    <input type="submit" class="btn btn-primary" value="Desbanear">
                              </form>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        </tr>
                              <td colspan=7>No se han encontrado denuncias</td>
                        <tr>
                        <?php endif; ?>
                  
                  </tbody>

            </table>
      </div>
      </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/baneos/listarBaneos.blade.php ENDPATH**/ ?>