
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
      <div class="table-responsive">
            <h1>CURSOS</h1>
           
                  <table class="table table-bordered bg-white text-dark" id="myTable">
                        <thead class="col-lg-12">
                              <tr>
                                    <th>NOMBRE</th>
                                    <th>ENLACE</th>
                              </tr>
                        </thead>
                        <tbody class="col-lg-12">
                              <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tr>
                                    <td><?php echo e($curso->nombre); ?></td>
                                    <td>
                                          <form action="informacionCurso" method="POST">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('POST'); ?> 
                                                <input type="hidden" name="codCurso" value="<?php echo e($curso->codCurso); ?>">
                                                <input type="submit" class="btn btn-primary" value="Información">
                                          </form>
                                    </td>
                              </tr>
                              
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                    <td colspan=2>No se han encontrado cursos</td>
                              </tr> 
                              <?php endif; ?>
                        </tbody>
                  </table>
          
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/cursos/listadoCursos.blade.php ENDPATH**/ ?>