
<?php $__env->startSection('contenido'); ?>

<table class="table table-bordered bg-white text-dark">
<thead>
        <tr>
            <th></th>
            <th>Mensaje</th>
            <th>Usuario</th>
            <th>Fecha</th>
            <th>Puntuación</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><img src="<?php echo e(asset('img/user.jpg')); ?>" alt="..." class="img-circle" width="50px" height="50px" style="border-radius: 50%"></td>
            <td>
                <form action="listarConsultas" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?> 
                    <input type="hidden" value="<?php echo e($consulta->codCon); ?>" name="codigo">
                    <input type="submit" class="btn btn-link" value="<?php echo e($consulta->nombre); ?>">
                </form>
            </td>
            <td>
                <?php echo e($consulta->codUsu); ?>

            </td>
            <td><?php echo e($consulta->fechaCreacion); ?></td>
            <td><?php echo e($consulta->puntuacion); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>No se han encontrado consultas</tr> 
        <?php endif; ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/cursos/consultasCursos.blade.php ENDPATH**/ ?>