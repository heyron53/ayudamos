<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="<?php echo e(asset(mix('css/app.css'))); ?>" rel="stylesheet">
      
      <title>Document</title>
</head>
<body>
      fdsafds
<?php echo $__env->yieldContent("contenido"); ?>
<script src="<?php echo e(asset(mix('js/app.js'))); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/layouts/plantillabase.blade.php ENDPATH**/ ?>