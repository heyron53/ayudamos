
<?php $__env->startSection('contenido'); ?>

<div class="container">

      <ul class="nav nav-tabs">
      <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="administrar">Incidencias</a>
      </li>
      <li class="nav-item">
            <a class="nav-link" href="listarUsuarios">Usuarios</a>
      </li>
      <li class="nav-item">
            <a class="nav-link" href="listarAsignaturas">Asignaturas</a>
      </li>
      <li class="nav-item">
            <a class="nav-link" href="listarCursos">Cursos</a>
      </li>
      </ul>

      <table>
            <tr>
                  <td></td>
            </tr>
            <tr>
                  <td></td>
            </tr>
      </table>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/main/administrar.blade.php ENDPATH**/ ?>