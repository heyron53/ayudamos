
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
      <h1><?php echo e($curso->nombre); ?></h1>

      <p>
            <?php echo e($curso->descripcion); ?>

      </p>
      <div class="row alert">
            <div class="table-responsive">
                  <table class="table table-bordered bg-white text-dark table stacktable" id="myTable">
                        <thead>
                              <tr>
                                    <th>ASIGNATURAS DEL CURSO</th>
                              </tr>
                        </thead>
                        <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tr>
                                    <td><?php echo e($asignatura->nombre); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                    <td>Este curso no tiene asignaturas por el momento</td>
                              </tr>
                              <?php endif; ?>
                        </tbody>
                  </table>
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/cursos/informacionCurso.blade.php ENDPATH**/ ?>