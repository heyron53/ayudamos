
<?php $__env->startSection('contenido'); ?>

<table>
    <tr>
        <th>Cod</th>
        <th>CodUsu</th>
        <th>Contenido</th>
        <th>Fecha</th>
        <th>Likes</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($pregunta["cod"]); ?></td>
        <td><?php echo e($pregunta["codusu"]); ?></td>
        <td><?php echo e($pregunta["contenido"]); ?></td>
        <td><?php echo e($pregunta["fecha"]); ?></td>
        <td><?php echo e($pregunta["likes"]); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr colspan="4">No se han encontrado preguntas</tr>
    <?php endif; ?>
</table>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/index.blade.php ENDPATH**/ ?>