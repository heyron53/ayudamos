
<?php $__env->startSection('contenido'); ?>
<!--
<table border="1">
    <tr>
        <th>Nickname</th>
        <th>Nombre</th>
        <th>Apellidos</th>
        <th>Correo</th>
        <th>Rol</th>
        <th>Conocimientos</th>
        <th>Puntuacion</th>
    </tr>
    <tr>
        <td><?php echo e(usuario["nickname"]); ?></td>
        <td><?php echo e(usuario["nombre"]); ?></td>
        <td><?php echo e(usuario["apellidos"]); ?></td>
        <td><?php echo e(usuario["correo"]); ?></td>
        <td><?php echo e(usuario["rol"]); ?></td>
        <td><?php echo e(usuario["conocimientos"]); ?></td>
        <td><?php echo e(usuario["puntuacion"]); ?></td>
    </tr>
</table>
-->


<table border="1">
    <tr>
        <th>Codigo Consulta</th>
        <th>Codigo Usuario</th>
        <th>Nombre</th>
        <th>Contenido</th>
        <th>ConsultaReferente</th>
        <th>Codigo tema</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($consulta["codCon"]); ?></td>
        <td><?php echo e($consulta["codUsu"]); ?></td>
        <td><?php echo e($consulta["nombre"]); ?></td>
        <td><?php echo e($consulta["contenido"]); ?></td>
        <td><?php echo e($consulta["consultaReferente"]); ?></td>
        <td><?php echo e($consulta["codTemas"]); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr colspan="4">No se han encontrado consultas</tr>
    <?php endif; ?>
</table>
<?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/\main\index.blade.php ENDPATH**/ ?>