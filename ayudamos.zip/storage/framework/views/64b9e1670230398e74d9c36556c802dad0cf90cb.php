
<?php $__env->startSection('contenido'); ?>

<div class="container alert">

      <ul class="nav nav-tabs">
            <li class="nav-item">
                  <a class="nav-link" href="listarIncidencias">Incidencias</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="listarUsuarios">Usuarios</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" href="listarAsignaturas">Asignaturas</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" href="listarCursos">Cursos</a>
            </li>
      </ul>
      <div class="row alert">
            <table id="users" class="table table-bordered bg-white text-dark table stacktable">
                  <thead>
                        <tr>
                              <th scope="col">Correo</th>
                              <th scope="col">Nickname</th>
                              <th scope="col">Nombre</th>
                              <th scope="col">Apellidos</th>
                              <th scope="col">ROL</th>
                              <th scope="col">Conocimientos</th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                              <td><?php echo e($usuario->correo); ?></td>
                              <td><?php echo e($usuario->nickname); ?></td>
                              <td><?php echo e($usuario->nombre); ?></td>
                              <td><?php echo e($usuario->apellidos); ?></td>
                              <td><?php echo e($usuario->rol); ?></td>
                              <td><?php echo e($usuario->conocimientos); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        </tr>
                              <td colspan=6>No se han encontrado usuarios</td>
                        <tr>
                        <?php endif; ?>
                  </tbody>
            </table>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/main/allUsers.blade.php ENDPATH**/ ?>