
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Crear curso</div>

                <div class="card-body">
                    <form method="POST" action="almacenarCursoEditado">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="form-group row">
                              <label for="nombre" class="col-md-4 col-form-label text-md-right">Nombre</label>

                              <div class="col-md-6">
                                    <input id="nombre" type="text" id="formGroupExampleInput" name="nombre" value="<?php echo e($curso->nombre); ?>">
                              </div>
                        </div>
                        
                        <div class="form-group row">
                              <label for="descripcion" class="col-md-4 col-form-label text-md-right">Contenido</label>
                            
                            <div class="col-md-8">
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="7">
                                <?php echo e($curso->descripcion); ?>

                                </textarea>
                            </div>
                        </div>

                        <input type="hidden" name="codCurso" value="<?php echo e($curso->codCurso); ?>"

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Editar
                                </button>
                            </div>
                        </div>
                  </form>
            </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/cursos/formEditarCurso.blade.php ENDPATH**/ ?>