
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
      <h1><?php echo e($asignatura->nombre); ?></h1>

      <p>
            <?php echo e($asignatura->descripcion); ?>

      </p>
      <div class="row alert">
            <div class="table-responsive">
                  <table class="table table-bordered bg-white text-dark table stacktable">
                        <thead>
                              <tr>
                                    <th>CURSO PERTENECIENTES</th>
                              </tr>
                        </thead>
                        <tbody>
                              <tr>
                                    <td><?php echo e($curso->nombre); ?></td>
                              </tr>
                        </tbody>
                  </table>
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/asignaturas/informacionAsignatura.blade.php ENDPATH**/ ?>