
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
      <h1>DENUNCIAS</h1>
    <ul class="nav nav-tabs">
    <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="listarUsuarios">Listar usuarios</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="listarDenuncias">Listar denuncias</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="listarBaneos">Listar baneos</a>
            </li>
    </ul>

    <div class="row alert">
      <div class="table-responsive">
            <table class="table table-bordered bg-white text-dark table stacktable" id="myTable">
                  <thead>
                        <tr>
                              <th scope="col">CodDenuncia</th>
                              <th scope="col">FechaCreacion</th>
                              <th scope="col">TipoDenuncia</th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $denuncias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denuncia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                              <td>
                              <form action="listarContenidoDenuncia" method="POST">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('POST'); ?> 
                                    <input type="hidden" name="codDenuncia" value="<?php echo e($denuncia->codDenuncia); ?>">
                                    <input type="submit" class="btn btn-link" name="enviar" value="<?php echo e($denuncia->codDenuncia); ?>">
                              </form>
                              </td>
                              <td><?php echo e($denuncia->fechaCreacion); ?></td>
                              <td><?php echo e($denuncia->tipoDenuncia); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        </tr>
                              <td colspan=6>No se han encontrado denuncias</td>
                        <tr>
                        <?php endif; ?>
                  
                  </tbody>

            </table>
      </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/denuncias/listarDenuncias.blade.php ENDPATH**/ ?>