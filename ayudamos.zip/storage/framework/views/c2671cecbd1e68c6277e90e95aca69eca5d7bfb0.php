<?php $__env->startSection('contenido'); ?>
      
      <form action="/login" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('POST'); ?>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <table>
                  <tr>
                        <td>
                        <label>Nombre de usuario</label>
                        </td>
                        <td>
                        <input type="text" id="nickname" name="nickname">
                        </td>
                  </tr>
                  <tr>
                        <td>
                        <label>Contraseña</label>
                        </td>
                        <td>
                        <input type="text" value="" id="password" name="contrasenya">
                        </td>
                  </tr>
                  <tr>
                        <td>
                        <input type="submit" name="enviar" id="enviar" value="Iniciar sesión">
                        </td>
                  </tr>
            </table>
      </form>
      <nav>
            <a href="<?php echo e(route("usuario.create")); ?>">Crear nuevo usuario</a>
      </nav>
      <form action="register" method="GET">
      <?php echo csrf_field(); ?>
      <?php echo method_field('GET'); ?> 
            <input type="submit" name="enviar" id="enviar" value="Crear nuevo usuario">
      </form>
      
<?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/login\login.blade.php ENDPATH**/ ?>