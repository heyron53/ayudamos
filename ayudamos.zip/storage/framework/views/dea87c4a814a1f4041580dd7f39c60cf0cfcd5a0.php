
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
      <div class="table-responsive">
            <h1>ASIGNATURAS</h1>
           
                  <table class="table table-bordered bg-white text-dark" id="myTable">
                        <thead class="col-lg-12">
                              <tr>
                                    <th>NOMBRE</th>
                                    <th>CURSO</th>
                                    <th>ENLACE</th>
                              </tr>
                        </thead>
                        <tbody class="col-lg-12">
                              <?php $__empty_1 = true; $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tr>
                                    <td><?php echo e($asignatura->nombre); ?></td>
                                    <td><?php echo e($asignatura->codCurso); ?></td>
                                    <td>
                                          <form action="informacionAsignatura" method="POST">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('POST'); ?> 
                                                <input type="hidden" name="codAsignatura" value="<?php echo e($asignatura->codAsignatura); ?>">
                                                <input type="submit" class="btn btn-primary" value="Información">
                                          </form>
                                    </td>
                              </tr>
                              
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                    <td colspan=2>No se han encontrado cursos</td>
                              </tr> 
                              <?php endif; ?>
                        </tbody>
                  </table>
          
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/asignaturas/listadoAsignaturas.blade.php ENDPATH**/ ?>