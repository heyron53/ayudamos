
<?php $__env->startSection('contenido'); ?>
<div class="container alert">
<div class="table-responsive">
<h1>CONSULTAS</h1>
    <table class="table table-bordered bg-white text-dark" id="myTable">
        <thead class="col-lg-12">
            <tr>
                <th>CodUsu</th>
                <th>RutaFichero</th>
                <th></th>
            </tr>
        </thead>
        <tbody class="col-lg-12">
            <?php $__empty_1 = true; $__currentLoopData = $ficheros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fichero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                  <td><?php echo e($fichero->nombre); ?></td>
                  <td><?php echo e($usuarios[$fichero->codUsu]); ?></td> 
                  <td>
                  <form action="descargarFichero" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="ruta" value="<?php echo e($fichero->rutaFichero); ?>">
                        <input type="submit" class="btn btn-primary" value="Descargar">
                    </form>
                  </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr >
                <td colspan=6>No se han encontrado consultas</td>
            </tr> 
            <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/ficheros/listarFicheros.blade.php ENDPATH**/ ?>