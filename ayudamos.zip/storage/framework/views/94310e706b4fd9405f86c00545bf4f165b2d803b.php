
<?php $__env->startSection('contenido'); ?>


<div class="container alert">
    <h1>ASIGNATURAS</h1>
    <ul class="nav nav-tabs">
    <li class="nav-item">
            <a class="nav-link" aria-current="page" href="listarCursos">Cursos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="listarAsignaturas">Asignaturas</a>
        </li>
    </ul>

    <div class="row alert">
        <div class="col-md-2">
            <ul class="list-group">
                <li><a href="listarAsignaturas" class="btn btn-primary nav-link alert">Listar</a></li>
                <li><a href="crearAsignatura" class="btn btn-primary nav-link alert">Crear</a></li>
            </ul>
        </div>
        <div class="table-responsive col-md-10">
        <table class="table table-bordered bg-white text-dark" id="myTable">
            <thead>
                <tr>
                    <th>ASIGNATURAS</th>
                    <th>CURSOS</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($asignatura->nombre); ?></td>
                    <td><?php echo e($asignatura->codCurso); ?></td>
                    <td>
                    <form method="POST" action="editarAsignatura">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                        <input type="hidden" name="codAsignatura" value="<?php echo e($asignatura->codCurso); ?>">
                        <input type="submit" class="btn btn-primary nav-link" name="enviar" value="Editar">
                    </form>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                <td colspan=3>No se han encontrado consultas</td>
                </tr> 
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/asignaturas/listarAsignaturas.blade.php ENDPATH**/ ?>