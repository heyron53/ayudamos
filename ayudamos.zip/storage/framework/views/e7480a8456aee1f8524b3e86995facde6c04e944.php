
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
    <div class="table-responsive col-md-12">
        <table class="table table-bordered bg-white text-dark" id="myTable">
            <tr>
                
                <th>Nombre</th>
                <th>CodAsignatura</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>

                <td><?php echo e($consulta->nombre); ?></td>
                <td><?php echo e($consulta->codAsignatura); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan=7>No se han encontrado consultas</td>
            </tr> 
            <?php endif; ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/login/consultasPropias.blade.php ENDPATH**/ ?>