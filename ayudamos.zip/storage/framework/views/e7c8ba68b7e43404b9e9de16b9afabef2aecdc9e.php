
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
      <h1>INCIDENCIAS</h1>
      <ul class="nav nav-tabs">
            <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="listarIncidencias">Todas</a>
            </li>
            <li class="nav-item">
                  <form action="listarIncidenciasUsuario" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="submit" class="btn btn-link nav-link" aria-current="page" name="enviar" value="Listar asignadas">
                  </form>
            </li>
            <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="incidenciasNoAsignadas">No asignadas</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="incidenciasAbiertas">Incidencias abiertas</a>
            </li>
            <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="incidenciasCerradas">Incidencias cerradas</a>
            </li>
      </ul>

      <div class="row alert">
            <div class="col-md-2">
                  <ul class="list-group">
                        <li><a href="crearIncidencia" class="btn btn-primary nav-link alert">Crear</a></li>
                  </ul>
            </div>
            <div class="table-responsive col-md-10">
            <table class="table table-bordered bg-white text-dark" id="myTable">
                        
                  <thead>
                        <tr>
                              <th>CODIGO</th>
                              <th>USUARIO</th>
                              <th>TITULO</th>
                              <th>CREACIÓN</th>
                              <th>CIERRE</th>
                              <th>ASIGNADO</th>
                              <th>ESTADO</th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                        <td><?php echo e($incidencia->codInci); ?></td>
                        <td><?php echo e($incidencia->codUsu); ?></td>
                        <td><?php echo e($incidencia->titulo); ?></td>
                        <td><?php echo e($incidencia->fechaCreacion); ?></td>
                        <td><?php echo e($incidencia->fechaCierre); ?></td>
                        <td><?php echo e($incidencia->codUsuAsignado); ?></td>
                        <td><?php echo e($incidencia->estado); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                              <td colspan=8>No se han encontrado consultas</td>
                        </tr> 
                        <?php endif; ?>
                  </tbody>
            </table>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/incidencias/listarIncidencias.blade.php ENDPATH**/ ?>