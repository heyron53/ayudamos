
<?php $__env->startSection('contenido'); ?>

<table border="1">
      <td>
            <a href="listarAsignaturas">Listar Asignaturas</a>
      </td>
      <td>
            <a href="listarCursos">Listar Cursos</a>
      </td>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/main/explorer.blade.php ENDPATH**/ ?>