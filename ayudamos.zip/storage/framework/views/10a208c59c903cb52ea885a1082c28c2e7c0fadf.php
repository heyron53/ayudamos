<form action="/profile" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?> 
    <input type="submit" name="enviar" id="enviar" value="Mi perfil">
</form><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/main\index.blade.php ENDPATH**/ ?>