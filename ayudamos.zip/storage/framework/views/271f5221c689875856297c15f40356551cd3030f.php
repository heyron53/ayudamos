<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(route('usuario.profile')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?> 
    <input type="submit" name="enviar" id="enviar" value="Mi perfil">
</form>
<table border="1">
    <tr>
        <th>CodCon</th>
        <th>codUsu</th>
        <th>Nombre</th>
        <th>Contenido</th>
        <th>ConsultaReferente</th>
        <th>CodTemas</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($consulta->codCon); ?></td>
        <td><?php echo e($consulta->codUsu); ?></td>
        <td><?php echo e($consulta->nombre); ?></td>
        <td><?php echo e($consulta->contenido); ?></td>
        <td><?php echo e($consulta->consultaReferente); ?></td>
        <td><?php echo e($consulta->codTemas); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>No se han encontrado consultas</tr> 
    <?php endif; ?>
</table><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/consultas/listarConsultas.blade.php ENDPATH**/ ?>