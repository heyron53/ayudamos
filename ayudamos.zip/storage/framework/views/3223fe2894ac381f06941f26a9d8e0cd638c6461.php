
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Denunciar</div>

                <div class="card-body">
                    <form method="POST" action="almacenarDenuncia">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="tipoDenuncia" value="<?php echo e($denuncia); ?>">
                        <input type="hidden" name="codConsulta" value="<?php echo e($consulta); ?>">
                        <div class="form-group row">
                              <label for="contenido" class="col-md-4 col-form-label text-md-right">Contenido</label>
                            
                            <div class="col-md-8">
                                <textarea class="form-control" id="contenido" name="contenido" placeholder="Introduce información sobre la denuncia (OPCIONAL)." rows="7"></textarea>
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Crear
                                </button>
                            </div>
                        </div>
                  </form>
            </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/denuncias/formCrearDenuncia.blade.php ENDPATH**/ ?>