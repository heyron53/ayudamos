

<?php $__env->startSection('contenido'); ?>
      <form action="almacenarConsultaHija" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('POST'); ?>
            <table>
                  <tr>
                        <td>
                              <label>Nombre consulta</label>
                        </td>
                        <td>
                              <input type="text" value="" id="nombre" name="nombre">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Contenido</label>
                        </td>
                        <td>
                              <input type="text" value="" id="contenido" name="contenido">
                        </td>
                  </tr>
                  
                  <input type="hidden" value="<?php echo e($padre); ?>" name="padre">  
                  <input type="hidden" value="<?php echo e($curso); ?>" name="curso"> 
                  <input type="hidden" value="<?php echo e($asignatura); ?>" name="asignatura">   
            </table>
            <input type="submit" name="Crear consulta" value="Responder">
      </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/consultas\formCrearConsultaHija.blade.php ENDPATH**/ ?>