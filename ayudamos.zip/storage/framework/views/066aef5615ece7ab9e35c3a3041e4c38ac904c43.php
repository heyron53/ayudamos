
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">FICHERO</div>

                <div class="card-body">
                    <form method="POST" action="almacenarFichero" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="codUsu" value="<?php echo e(session('user')['correo']); ?>">
                        
                        <div class="form-group row">
                            <label for="fichero" class="col-md-2 col-form-label text-md-right">Sube un fichero</label>

                            <div class="col-md-10">
                                <input type="file" class="btn btn-light" name="fichero" accept=".pdf">
                            </div>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Guardar">
                  </form>
            </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/ficheros/formCrearFichero.blade.php ENDPATH**/ ?>