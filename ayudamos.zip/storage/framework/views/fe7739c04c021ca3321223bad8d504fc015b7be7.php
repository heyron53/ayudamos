
<?php $__env->startSection('contenido'); ?>

<table border="1">
    <tr>
        <th>Código Usuario</th>
        <th>Nombre</th>
        <th>Apellidos</th>
        <th>Correo</th>
        <th>ROL</th>
        <th>Conocomientos</th>
        <th>Puntuación</th>
    </tr>
    
    <tr>
        <td><?php echo e($usuario->nickname); ?></td>
        <td><?php echo e($usuario->nombre); ?></td>
        <td><?php echo e($usuario->apellidos); ?></td>
        <td><?php echo e($usuario->correo); ?></td>
        <td><?php echo e($usuario->rol); ?></td>
        <td><?php echo e($usuario->conocimientos); ?></td>
        <td><?php echo e($usuario->puntuacion); ?></td>
    </tr>
</table><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/profile\profile.blade.php ENDPATH**/ ?>