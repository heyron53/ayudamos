
<?php $__env->startSection('contenido'); ?>

<div class="container alert">
    <div class="row justify-content-center alert">
      <form action="almacenarCambioUsuario" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('POST'); ?>
      <input type="hidden" name="correo" value="<?php echo e(session("user")["correo"]); ?>">
      <div class="card">
            <div class="card-header">
                  Editar perfil
            </div>
            <div class="card-body">
                        <table class="table alert col-md-10">
                        <tbody>
                        <tr>
                              <th scope="row">Foto de perfil</th>
                              <td><input type="file" name="imagen"></td>
                        </tr>
                        <tr>
                              <th scope="row">Nickname</th>
                              <td><input type="text" name="nickname" value="<?php echo e(session("user")["nickname"]); ?>"></td>
                        </tr>
                        <tr>
                              <th scope="row">Nombre</th>
                              <td><input type="text" name="nombre" value="<?php echo e(session("user")["nombre"]); ?>"></td>
                        </tr>
                        <tr>
                              <th scope="row">Apellidos</th>
                              <td><input type="text" name="apellidos" value="<?php echo e(session("user")["apellidos"]); ?>"></td>
                        </tr>
                        <tr>
                              <th scope="row">Conocimientos</th>
                              <td><select multiple name="conocimientos[]" id="conocimientos[]">
                                          <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                          <option value="<?php echo e($curso->nombre); ?>"><?php echo e($curso->nombre); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                No se han encontrado cursos
                                          <?php endif; ?>
                                    </select></td>
                        </tr>
                        
                        <tr>
                              <td>
                                    <input type="submit" class="btn btn-primary" value="Editar">
                              </td>
                        </tr>
                        </tbody>
                  </table>

            </div>
      </div>
      </form>

    </div>
</div>
       
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/usuarios/formEditarUsuario.blade.php ENDPATH**/ ?>