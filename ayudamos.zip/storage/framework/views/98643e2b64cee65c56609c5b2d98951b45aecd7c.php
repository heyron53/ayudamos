<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Registro</title>
</head>
<body>
      <form action="<?php echo e(route('usuario.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('POST'); ?>
      <input type="hidden" value="NORMAL" name="rol" id="rol">
      <input type="hidden" value="0" name="puntuacion" id="puntuacion">
            <table>
                  <tr>
                        <td>
                              <label>Nombre de usuario</label>
                        </td>
                        <td>
                              <input type="text" value="" id="nickname" name="nickname">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Contraseña</label>
                        </td>
                        <td>
                              <input type="password" value="" id="password" name="password">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Confirmar contraseña</label>
                        </td>
                        <td>
                              <input type="password" value="" id="confirmpassword" name="confirmcontrasenya">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Nombre</label>
                        </td>
                        <td>
                              <input type="text" value="" id="nombre" name="nombre">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Apellidos</label>
                        </td>
                        <td>
                              <input type="text" value="" id="apellidos" name="apellidos">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Correo</label>
                        </td>
                        <td>
                              <input type="text" value="" id="correo" name="correo">
                        </td>
                  </tr>
                  <tr>
                        <td>
                              <label>Conocimientos</label>
                        </td>
                        <td>
                              <select name="conocimientos" id="conocimientos">
                                    <option value="MATH">Matemáticas</option>
                                    <option value="CAST">Castellano</option>
                                    <option value="INGL">Inglés</option>
                                    <option value="VALN">Valenciano</option>
                                    <option value="IFTC">Informática</option>
                                    <option value="NO" selected>No específico</option>
                              </select>
                        </td>
                  </tr>
                  <tr>
                        <td>
                        <input type="submit" name="enviar" id="enviar" value="Registrar">
                        </td>
                  </tr>
            </table>
      </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\PROYECTO\ayudamos\resources\views/login\register.blade.php ENDPATH**/ ?>